
function multiply(price, count) {
  console.log("multiply 시작", price, count);
  return price * count;
}
function checkout(count) {
  console.log("checkout 시작", count);
  const subtotal = multiply(3000, count);
  console.log("checkout으로 복귀", subtotal);
  return subtotal + 500;
}
const total = checkout(2);
console.log("바깥 코드로 복귀", total);
