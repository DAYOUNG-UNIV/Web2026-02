const like = document.querySelector("#like");
like.addEventListener("click", () => {
  const active = like.getAttribute("aria-pressed") === "true";
  like.setAttribute("aria-pressed", String(!active));
  like.textContent = active ? "♡ 관심" : "♥ 관심 표시됨";
});
document.querySelector("#zoom").addEventListener("click", () => {
  document.querySelector("#intro").classList.toggle("large");
});
document.querySelector("#filter").addEventListener("change", (event) => {
  document.querySelectorAll("[data-kind]").forEach((item) => {
    item.hidden = event.target.value !== "all" && item.dataset.kind !== event.target.value;
  });
});