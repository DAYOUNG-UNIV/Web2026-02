const menu = "차";
let quantity = 2;
const total = (price, count) => price * count;
console.log(`${menu} ${quantity}개`);
console.log(total(2500, quantity));