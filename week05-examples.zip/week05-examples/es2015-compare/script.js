var menu = "차";
var quantity = 2;
function total(price, count) {
  return price * count;
}
console.log(menu + " " + quantity + "개");
console.log(total(2500, quantity));