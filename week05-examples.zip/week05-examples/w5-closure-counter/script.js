
function makeCounter() {
  let count = 0;
  return function () {
    count = count + 1;
    return count;
  };
}
let nextA = makeCounter();
let nextB = makeCounter();
document.querySelector("#a-next").addEventListener("click", function () {
  document.querySelector("#a-value").textContent = nextA();
  document.querySelector("#counter-note").textContent = "A의 count만 1 증가했습니다.";
});
document.querySelector("#b-next").addEventListener("click", function () {
  document.querySelector("#b-value").textContent = nextB();
  document.querySelector("#counter-note").textContent = "B의 count만 1 증가했습니다.";
});
document.querySelector("#counters-reset").addEventListener("click", function () {
  nextA = makeCounter();
  nextB = makeCounter();
  document.querySelector("#a-value").textContent = 0;
  document.querySelector("#b-value").textContent = 0;
  document.querySelector("#counter-note").textContent = "새 함수와 새로운 count를 만들었습니다.";
});
