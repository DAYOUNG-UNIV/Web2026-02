
function greet() {
  console.log("안녕하세요!");
}
greet();
greet();

function greetUser(name) {
  console.log(name + "님, 안녕하세요!");
}
greetUser("민지");
greetUser("서준");

function add(a, b) {
  return a + b;
}
const result = add(5, 3);
console.log(result);
