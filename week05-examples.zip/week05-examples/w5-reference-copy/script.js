
let count = 2;
let anotherCount = count;
anotherCount = 3;
console.log(count, anotherCount);

const original = { title: "숲" };
const shared = original;
const copy = { title: original.title };
shared.title = "바다";
console.log(original.title, shared.title, copy.title);
console.log(original === shared);
console.log(original === copy);
