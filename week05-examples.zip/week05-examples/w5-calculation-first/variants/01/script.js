const price = 3000;
const quantity = 0;
const total = price * quantity;
console.log(total);
console.log(quantity > 0);