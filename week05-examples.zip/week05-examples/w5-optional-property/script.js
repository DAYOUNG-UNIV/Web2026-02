
const artwork = { title: "숲", credit: null, count: 0 };
console.log(artwork.credit?.name ?? "작가 미기재");
console.log(artwork.count ?? 3); // 0 유지
console.log(artwork.count || 3); // 3
const blank = { credit: { name: "" } };
console.log(blank.credit?.name ?? "작가 미기재"); // 빈 문자열 유지
