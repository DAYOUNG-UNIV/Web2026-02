
const votes = ["숲", "바다", "숲"];
const unique = new Set(votes);
console.log("배열:", votes.length);
console.log("Set:", unique.size, [...unique]);
unique.add("숲");
console.log("같은 값 추가:", unique.size);
const counts = new Map();
for (const title of votes) {
  const previous = counts.get(title) ?? 0;
  counts.set(title, previous + 1);
}
console.log("숲:", counts.get("숲"));
console.log("없는 키:", counts.get("골목"));
console.log("키 존재:", counts.has("바다"));
