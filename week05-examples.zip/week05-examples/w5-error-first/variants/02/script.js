const count = 2;
console.log(Count);