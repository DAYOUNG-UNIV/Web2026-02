
const works = [
  { title: "숲", price: 1000 },
  { title: "바다", price: 3000 },
  { title: "도시", price: 5000 }
];
function readTitle(work) {
  return work.title;
}
function affordable(work) {
  return work.price <= 3000;
}
const titles = works.map(readTitle);
const selected = works.filter(affordable);
const first = works.find(affordable);
console.log(titles);
console.log(selected);
console.log(first);
console.log(works.length);
