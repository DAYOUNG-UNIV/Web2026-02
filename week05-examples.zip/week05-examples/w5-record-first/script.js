const exhibition = {
  title: "쉬는 시간",
  photoCount: 3
};
console.log(exhibition.title);
exhibition.title = "여행의 기록";
console.log(exhibition.title);