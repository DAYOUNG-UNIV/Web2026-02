
const topics = ["쉬는 시간", "여행", "전시 관람"];
if (topics.length === 0) {
  console.log("먼저 주제를 넣으세요.");
} else {
  const randomValue = Math.random();
  const index = Math.floor(randomValue * topics.length);
  console.log("난수:", randomValue);
  console.log("인덱스:", index);
  console.log("주제:", topics[index]);
}
