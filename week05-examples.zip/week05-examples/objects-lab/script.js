const menus = [
  { name: "차", price: 2500 },
  { name: "커피", price: 3000 }
];
console.log(menus[1].name);
console.log(menus[1].price);
console.log(Array.isArray(menus));