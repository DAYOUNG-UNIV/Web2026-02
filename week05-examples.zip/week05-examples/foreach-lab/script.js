const menus = ["차", "커피"];
menus.forEach((menu, index) => {
  console.log(index, menu);
});