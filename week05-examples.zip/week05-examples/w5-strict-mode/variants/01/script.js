"use strict";
let count = 0;
coutn = count + 1;
console.log(count);