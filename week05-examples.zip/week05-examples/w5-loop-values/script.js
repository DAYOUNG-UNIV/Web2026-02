
const titles = ["숲", "바다", "골목"];
for (const title of titles) {
  console.log("값:", title);
}
for (const key in titles) {
  console.log("키:", key, typeof key);
}
const artwork = { title: "숲", year: 2026 };
for (const key of Object.keys(artwork)) {
  console.log(key, artwork[key]);
}
