
const buttons = document.querySelectorAll(".choice");
const output = document.querySelector("#selected");

buttons.forEach(function (button) {
  function selectThisButton() {
    output.textContent = button.textContent + "을 선택했습니다.";
  }
  button.addEventListener("click", selectThisButton);
});
