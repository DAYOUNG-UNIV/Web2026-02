
const works = [
  { title: "새벽", caption: "하루를 시작하는 빛", color: "#bdd8ea" },
  { title: "오후", caption: "길게 드리운 나무의 그림자", color: "#93bda2" },
  { title: "저녁", caption: "집으로 돌아가는 길", color: "#e2ad93" }
];
let currentIndex = 0;
const previous = document.querySelector("#previous-work");
const next = document.querySelector("#next-work");

function showWork() {
  const work = works[currentIndex];
  document.querySelector("#work-title").textContent = work.title;
  document.querySelector("#work-caption").textContent = work.caption;
  document.querySelector("#picture").style.background = work.color;
  document.querySelector("#picture").setAttribute("aria-label", work.title + "의 색상 도해");
  document.querySelector("#work-count").textContent = (currentIndex + 1) + " / " + works.length;
  previous.disabled = currentIndex === 0;
  next.disabled = currentIndex === works.length - 1;
}
function previousWork() {
  if (currentIndex > 0) currentIndex = currentIndex - 1;
  showWork();
}
function nextWork() {
  if (currentIndex < works.length - 1) currentIndex = currentIndex + 1;
  showWork();
}
previous.addEventListener("click", previousWork);
next.addEventListener("click", nextWork);
showWork();
