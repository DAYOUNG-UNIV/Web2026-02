
const fruits = ["사과", "바나나", "딸기"];
const list = document.querySelector("#fruit-list");

for (let i = 0; i < fruits.length; i = i + 1) {
  const item = document.createElement("li");
  item.textContent = fruits[i];
  list.appendChild(item);
  console.log(i, fruits[i]);
}
