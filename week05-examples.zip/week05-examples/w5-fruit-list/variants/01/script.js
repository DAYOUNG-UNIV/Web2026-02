const fruits = ["사과", "바나나", "딸기"];
const list = document.querySelector("#fruit-list");

fruits.forEach(function (fruit, index) {
  const item = document.createElement("li");
  item.textContent = fruit;
  list.appendChild(item);
  console.log(index, fruit);
});