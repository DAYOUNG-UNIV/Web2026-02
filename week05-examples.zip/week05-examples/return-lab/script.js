function calculateTotal(price, count) {
  return price * count;
}
const total = calculateTotal(3000, 2);
console.log(total);
console.log(total + 500);