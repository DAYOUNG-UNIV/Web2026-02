const menus = ["차", "커피", "주스"];
for (let i = 0; i < menus.length; i++) {
  console.log(menus[i]);
}