
const button = document.querySelector("#increase");
const output = document.querySelector("#count");
let count = 0;

function render() {
  output.textContent = String(count);
}
function increase() {
  count = count + 1;
  render();
}
button.addEventListener("click", increase);
