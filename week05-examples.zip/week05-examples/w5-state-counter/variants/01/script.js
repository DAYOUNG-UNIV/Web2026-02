
const button = document.querySelector("#increase");
const output = document.querySelector("#count");
function increase() {
  let count = 0;
  count = count + 1;
  output.textContent = String(count);
}
button.addEventListener("click", increase);
