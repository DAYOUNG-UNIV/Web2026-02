
let name = "Kim";
console.log(name);
name = "Lee";
console.log(name);

const age = 25;
console.log(age);

let currentStudents = 50;
currentStudents = 52;
console.log(currentStudents);
