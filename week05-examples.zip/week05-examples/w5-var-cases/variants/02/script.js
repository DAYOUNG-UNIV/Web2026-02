const colors = ["blue"];
colors.push("green");
console.log(colors);
// colors = ["red"]; 는 재대입이므로 오류입니다.