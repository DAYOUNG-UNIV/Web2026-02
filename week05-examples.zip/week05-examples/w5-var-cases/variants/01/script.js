const university = "우리 대학";
university = "다른 대학";
console.log(university);