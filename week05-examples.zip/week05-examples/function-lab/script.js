function calculateTotal(price, count) {
  return price * count;
}
console.log(calculateTotal(3000, 2));
console.log(calculateTotal(2500, 3));