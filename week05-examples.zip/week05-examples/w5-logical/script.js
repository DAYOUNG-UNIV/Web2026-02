
function readRight() {
  console.log("오른쪽을 실행했습니다.");
  return "오른쪽 값";
}
console.log(false && readRight());
console.log(true || readRight());
console.log(true && readRight());
console.log(false || readRight());

const userName = null;
console.log(userName || "익명");
