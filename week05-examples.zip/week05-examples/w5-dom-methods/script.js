
const title = document.querySelector("#title");
title.textContent = "새로운 제목";
title.style.color = "red";

document.querySelector("#plain").textContent = "<strong>중요</strong>";
document.querySelector("#markup").innerHTML = "<strong>중요</strong>";
