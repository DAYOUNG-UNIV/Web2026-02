
const artwork = { title: "숲", year: 2026 };
const key = "title";
console.log(artwork.title);
console.log(artwork["title"]);
console.log(artwork[key]);
console.log(artwork.key);
console.log(artwork.missing);
