const quantity = 0;
if (quantity > 0) {
  console.log("선택한 수량이 있습니다.");
  console.log(quantity);
}
console.log("검사를 마쳤습니다.");