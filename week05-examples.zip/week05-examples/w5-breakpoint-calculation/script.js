
const raw = "2";
const quantity = raw;
const total = quantity + 1;
console.log(total);
