const raw = "2";
const quantity = Number(raw);
const total = quantity + 1;
console.log(total);