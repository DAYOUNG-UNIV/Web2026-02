const quantity = 6;
if (quantity >= 1 && quantity <= 5) {
  console.log("확인 가능한 수량입니다.");
} else {
  console.log("1~5개로 입력하세요.");
}