
const startButton = document.querySelector("#request-start");
const state = document.querySelector("#promise-state");
const result = document.querySelector("#promise-result");
function prepareWorks(shouldFail) {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      if (shouldFail) {
        reject(new Error("목록 준비에 실패했습니다."));
      } else {
        resolve(["숲", "바다"]);
      }
    }, 900);
  });
}
async function loadWorks() {
  const shouldFail = document.querySelector("#request-mode").value === "failure";
  startButton.disabled = true;
  state.textContent = "pending · 대기";
  result.textContent = "목록을 준비하고 있습니다.";
  try {
    const works = await prepareWorks(shouldFail);
    state.textContent = "fulfilled · 성공";
    result.textContent = works.join(" · ");
  } catch (error) {
    state.textContent = "rejected · 실패";
    result.textContent = error.message;
  } finally {
    startButton.disabled = false;
  }
}
let otherCount = 0;
document.querySelector("#other-click").addEventListener("click", function () {
  otherCount = otherCount + 1;
  document.querySelector("#other-count").textContent = otherCount;
});
startButton.addEventListener("click", loadWorks);
