
const limit = 3;
let before = 0;
while (before < limit) {
  console.log("while:", before);
  before = before + 1;
}
let after = 0;
do {
  console.log("do...while:", after);
  after = after + 1;
} while (after < limit);
