console.log("2" + "2");
console.log("2" + "2" - "2");
console.log(Number("2") + Number("2"));
console.log("2" === 2);
console.log("" == 0);