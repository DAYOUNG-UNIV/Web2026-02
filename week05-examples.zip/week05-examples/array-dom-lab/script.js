const menus = ["차", "커피", "주스"];
document.querySelector("#load").addEventListener("click", () => {
  const list = document.querySelector("#menus");
  list.replaceChildren();
  menus.forEach((name) => {
    const item = document.createElement("li");
    const button = document.createElement("button");
    button.textContent = name;
    button.addEventListener("click", () => {
      document.querySelector("#choice").textContent = name + " 선택";
    });
    item.appendChild(button);
    list.appendChild(item);
  });
});