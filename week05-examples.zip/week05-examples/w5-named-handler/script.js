
const title = document.querySelector("#title");
const button = document.querySelector("#change");

function changeTitle() {
  title.style.color = "red";
  console.log("클릭 처리 함수가 실행되었습니다.");
}

button.addEventListener("click", changeTitle);
