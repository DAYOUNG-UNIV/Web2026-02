
const list = document.querySelector("#works");
const saved = document.querySelectorAll("#works li");
let latest = saved;
const output = document.querySelector("#selection-count");
function report() {
  output.textContent = "처음 목록 " + saved.length + "개 / "
    + "다시 선택한 목록 " + latest.length + "개 / "
    + "현재 DOM " + list.children.length + "개";
}
document.querySelector("#add-work").addEventListener("click", function () {
  const item = document.createElement("li");
  item.textContent = "추가한 작품";
  list.appendChild(item);
  report();
});
document.querySelector("#read-again").addEventListener("click", function () {
  latest = document.querySelectorAll("#works li");
  report();
});
document.querySelector("#rename-first").addEventListener("click", function () {
  saved[0].textContent = "글자를 바꾼 숲";
});
report();
