
const one = "20";
const two = 10;
console.log(one + two);
console.log(Number(one) + two);
console.log("2" + "2" - "2");

let value = 20;
value = "John";
console.log(typeof value);
