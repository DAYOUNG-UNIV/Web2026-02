const message = document.querySelector("#message");
document.querySelector("#change").addEventListener("click", () => {
  message.textContent = "신청 내용을 먼저 확인하세요.";
});