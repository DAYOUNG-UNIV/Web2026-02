const available = true;
const message = available ? "신청 가능" : "마감";
console.log(message);