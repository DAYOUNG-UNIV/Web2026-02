const input = "2";
console.log(input === 2);
console.log(input == 2);
console.log(Number(input) === 2);
console.log("" == 0);
console.log("" === 0);