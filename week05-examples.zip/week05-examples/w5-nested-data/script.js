
const questions = [
  {
    text: "어떤 관람을 좋아하나요?",
    options: [
      { text: "공간 둘러보기", type: "walk" },
      { text: "작품 자세히 보기", type: "look" }
    ]
  }
];
const question = questions[0];
const option = question.options[1];
console.log(question.text);
console.log(option.text);
console.log(option.type);
console.log(questions[0].options[1].type);
