if (true) {
  var oldCount = 2;
}
console.log(oldCount);

if (true) {
  let newCount = 2;
}
try {
  console.log(newCount);
} catch (error) {
  console.log(error.name);
}