
console.log(Number("123"));
console.log(Number("123ABC"));
console.log(String(456));
console.log(Boolean(1));
console.log(parseInt("123.45", 10));
console.log(parseInt("123AB", 10));
console.log(Number(""));
console.log(Number.isNaN(Number("hello")));
