let count = 1;
if (true) {
  let count = 2;
  console.log(count);
}
console.log(count);