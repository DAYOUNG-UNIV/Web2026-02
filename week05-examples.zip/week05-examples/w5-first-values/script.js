console.log(2);
console.log("안녕하세요");
console.log(2 + 3);