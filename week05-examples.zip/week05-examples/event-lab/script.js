function showMessage() {
  document.querySelector("#result").textContent = "버튼을 눌렀습니다.";
}
const button = document.querySelector("#confirm");
button.addEventListener("click", showMessage);