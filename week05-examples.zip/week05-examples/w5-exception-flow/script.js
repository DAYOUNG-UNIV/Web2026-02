
function calculate() {
  const log = [];
  document.querySelectorAll(".box").forEach(function (box) {
    box.classList.remove("active");
  });
  try {
    document.querySelector("#try-box").classList.add("active");
    log.push("1. try 시작");
    const count = Number(document.querySelector("#error-input").value);
    if (!Number.isInteger(count) || count < 1) {
      throw new Error("인원은 1 이상의 정수여야 합니다.");
    }
    log.push("2. 인원 확정: " + count);
  } catch (error) {
    document.querySelector("#catch-box").classList.add("active");
    log.push("오류 처리: " + error.message);
  } finally {
    document.querySelector("#finally-box").classList.add("active");
    log.push("3. finally: 처리 종료");
  }
  log.push("4. try/catch 다음 문장");
  document.querySelector("#error-log").textContent = log.join("\n");
}
document.querySelector("#error-run").addEventListener("click", calculate);
