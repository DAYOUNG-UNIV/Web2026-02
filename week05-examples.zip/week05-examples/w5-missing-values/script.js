
let title;
const caption = "";
const selection = null;
console.log(title, typeof title);
console.log(caption.length, typeof caption);
console.log(selection, selection === null);
console.log(Number("그림"), Number.isNaN(Number("그림")));

try {
  console.log(notDeclaredArtwork);
} catch (error) {
  console.log(error.name);
}
