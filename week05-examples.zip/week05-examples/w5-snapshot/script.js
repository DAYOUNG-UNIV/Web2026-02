
const price = 3000;
let quantity = 2;
let total = price * quantity;
quantity = 3;
console.log("수량만 변경:", quantity, total);
total = price * quantity;
console.log("다시 계산:", quantity, total);
