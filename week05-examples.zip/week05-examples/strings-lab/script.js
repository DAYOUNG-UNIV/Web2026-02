const menu = "차";
const count = 2;
console.log(menu + " " + count + "개");
console.log(`${menu} ${count}개`);