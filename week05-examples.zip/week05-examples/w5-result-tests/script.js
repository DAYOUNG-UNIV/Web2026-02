
function calculate(raw) {
  const quantity = Number(raw);
  if (raw.trim() === "" || !Number.isFinite(quantity) ||
      !Number.isInteger(quantity) || quantity < 1 || quantity > 5) {
    return "입력 오류";
  }
  return quantity * 3000;
}
const cases = [
  { input: "2", expected: 6000 },
  { input: "1", expected: 3000 },
  { input: "5", expected: 15000 },
  { input: "", expected: "입력 오류" },
  { input: "0", expected: "입력 오류" },
  { input: "6", expected: "입력 오류" },
  { input: "2.5", expected: "입력 오류" },
  { input: "3개", expected: "입력 오류" }
];
cases.forEach(function (test) {
  const actual = calculate(test.input);
  console.log(test.input, "기대:", test.expected,
    "실제:", actual, "일치:", actual === test.expected);
});
