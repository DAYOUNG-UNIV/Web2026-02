
const title = document.getElementById("title");
const firstButton = document.querySelector(".btn");
const items = document.querySelectorAll("li");

console.log(title.textContent);
console.log(firstButton.textContent);
console.log(items.length);
console.log(document.querySelector(".missing"));
console.log(document.querySelectorAll(".missing").length);
