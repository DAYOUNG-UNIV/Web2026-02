function checkScope() {
  if (true) {
    let count = 2;
    console.log(count);
  }
}
checkScope();