function checkScope() {
  if (true) {
    var count = 2;
  }
  console.log(count);
}
checkScope();