function checkScope() {
  if (true) {
    var count = 2;
  }
}
checkScope();
console.log(count);