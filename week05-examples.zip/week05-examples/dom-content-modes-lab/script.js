const result = document.querySelector("#result");
const sample = "<strong>강조</strong> 문장";
document.querySelector("#plain").addEventListener("click", () => {
  result.textContent = sample;
});
document.querySelector("#markup").addEventListener("click", () => {
  result.innerHTML = sample;
});