console.log("안녕하세요.");
console.log(2 + 3);
console.log("수량", 2);