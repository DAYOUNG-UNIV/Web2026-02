
function calculateTotal(prices) {
  const TAX_RATE = 0.1;
  let total = 0;
  for (const price of prices) {
    total = total + price;
  }
  return total * (1 + TAX_RATE);
}
console.log(calculateTotal([10000, 20000]));
