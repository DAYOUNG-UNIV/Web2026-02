const button = document.querySelector("#theme");
button.addEventListener("click", () => {
  const active = document.body.classList.toggle("dark");
  button.setAttribute("aria-pressed", String(active));
  button.textContent = active ? "밝은 테마" : "어두운 테마";
});