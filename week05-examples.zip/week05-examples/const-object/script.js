const menu = { name: "차", price: 2500 };
menu.price = 3000;
console.log(menu.price);
// menu = {}; 는 다시 대입이므로 오류입니다.