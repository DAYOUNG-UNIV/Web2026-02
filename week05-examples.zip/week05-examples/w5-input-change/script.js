
const log = document.querySelector("#event-log");
let history = "";
function record(event) {
  const element = event.currentTarget;
  let value = element.value;
  if (element.type === "checkbox") value = element.checked;
  history = event.type + " / " + element.id + " / " + value + "\n" + history;
  log.textContent = history;
}
const caption = document.querySelector("#caption");
const agree = document.querySelector("#agree");
caption.addEventListener("input", record);
caption.addEventListener("change", record);
agree.addEventListener("input", record);
agree.addEventListener("change", record);
document.querySelector("#clear-log").addEventListener("click", function () {
  history = "";
  log.textContent = "이벤트 대기";
});
