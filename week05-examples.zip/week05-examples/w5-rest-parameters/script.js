
function sum(...scores) {
  let total = 0;
  for (const score of scores) {
    total = total + score;
  }
  return total;
}
console.log(sum(2, 3, 1)); // scores는 [2, 3, 1]
console.log(sum()); // scores는 []
const points = [2, 3, 1];
console.log(sum(...points)); // 배열을 인수로 펼침
