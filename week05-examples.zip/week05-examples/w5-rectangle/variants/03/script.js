function calculateArea(width, height) {
  return width * height;
}
const first = calculateArea(10, 5);
const second = calculateArea(20, 4);
console.log(first + second);