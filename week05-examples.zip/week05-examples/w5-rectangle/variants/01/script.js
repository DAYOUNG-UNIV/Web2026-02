function calculateArea() {
  const width = 10;
  const height = 5;
  console.log(width * height);
}
calculateArea();
calculateArea();