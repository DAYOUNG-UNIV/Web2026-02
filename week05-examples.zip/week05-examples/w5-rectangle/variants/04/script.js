const calculateArea = (width, height) => width * height;
console.log(calculateArea(10, 5));
console.log(calculateArea(20, 4));