function calculateArea(width, height) {
  console.log(width * height);
}
calculateArea(10, 5);
calculateArea(20, 4);
calculateArea(100, 7);