
const width1 = 10;
const height1 = 5;
console.log(width1 * height1);

const width2 = 20;
const height2 = 4;
console.log(width2 * height2);
