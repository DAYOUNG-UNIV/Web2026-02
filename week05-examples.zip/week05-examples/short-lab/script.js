console.log(true && "진행");
console.log(false && "진행");
console.log("" || "이름 없음");
console.log(0 || 1);
console.log(0 ?? 1);