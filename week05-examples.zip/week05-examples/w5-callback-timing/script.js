
const log = document.querySelector("#order-log");
const cancelButton = document.querySelector("#cancel-order");
let timerId = null;
function write(text) {
  log.textContent = log.textContent + text + "\n";
}
function later() {
  write("2. 콜백 실행");
  timerId = null;
  cancelButton.disabled = true;
}
document.querySelector("#run-order").addEventListener("click", function () {
  if (timerId !== null) clearTimeout(timerId);
  timerId = null;
  log.textContent = "";
  cancelButton.disabled = true;
  write("1. 시작");
  if (document.querySelector("#callback-mode").value === "timer") {
    const delay = Number(document.querySelector("#callback-delay").value);
    timerId = setTimeout(later, delay);
    cancelButton.disabled = false;
  } else {
    ["작품"].forEach(later);
  }
  write("3. 다음 문장");
});
cancelButton.addEventListener("click", function () {
  clearTimeout(timerId);
  timerId = null;
  cancelButton.disabled = true;
  write("예약을 취소했습니다.");
});
