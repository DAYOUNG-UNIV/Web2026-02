function double(value) {
  console.log(value * 2);
}

const result = double(3);
console.log("반환값:", result);