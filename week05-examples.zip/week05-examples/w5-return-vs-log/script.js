function double(value) {
  return value * 2;
}

const result = double(3);
console.log("반환값:", result);