
const form = document.querySelector("#order");
const input = document.querySelector("#quantity");
const output = document.querySelector("#total");
const log = document.querySelector("#validation-log");

input.addEventListener("input", function () {
  output.textContent = "값을 바꿨습니다. 다시 계산하세요.";
  log.textContent = "아직 제출하지 않았습니다.";
});
input.addEventListener("invalid", function () {
  output.textContent = "입력 조건을 확인하세요.";
  log.textContent = "① 브라우저 검사 실패 → submit은 발생하지 않음";
});
document.querySelector("#skip-native").addEventListener("change", function (event) {
  form.noValidate = event.currentTarget.checked;
  log.textContent = "HTML 검사 생략: " + form.noValidate;
});
form.addEventListener("submit", function (event) {
  event.preventDefault();
  log.textContent = "② submit 발생 → 기본 제출 취소\n";
  const raw = input.value;
  const quantity = Number(raw);
  if (raw.trim() === "" || !Number.isFinite(quantity) ||
      !Number.isInteger(quantity) || quantity < 1 || quantity > 5) {
    output.textContent = "1~5개의 정수를 입력하세요.";
    log.textContent += "③ JavaScript 검사 실패 → 계산 중단";
    return;
  }
  output.textContent = quantity * 3000 + "원";
  log.textContent += "③ JavaScript 검사 통과 → 계산 → 결과 표시";
});
