
const artwork = {
  title: "숲의 아침",
  year: 2026
};
console.log(artwork.title);
artwork.title = "비 온 뒤의 숲";
console.log(artwork.title);

const guide = {
  greet: function () {
    return "전시에 오신 것을 환영합니다.";
  }
};
console.log(guide.greet());
