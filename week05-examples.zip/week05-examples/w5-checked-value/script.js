
const interest = document.querySelector("#interest");
const valueOutput = document.querySelector("#choice-value");
const checkedOutput = document.querySelector("#choice-checked");
const message = document.querySelector("#choice-message");

function readChoice() {
  valueOutput.textContent = interest.value;
  checkedOutput.textContent = String(interest.checked);
  if (interest.checked) {
    message.textContent = "소식 받기를 선택했습니다.";
  } else {
    message.textContent = "소식 받기를 선택하지 않았습니다.";
  }
}

interest.addEventListener("change", readChoice);
readChoice();
