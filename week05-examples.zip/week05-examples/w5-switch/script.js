
const type = "walk";
let title;
switch (type) {
  case "walk":
    title = "공간을 둘러보는 유형";
    break;
  case "look":
    title = "작품에 머무르는 유형";
    break;
  default:
    title = "아직 정하지 않은 유형";
}
console.log(title);
