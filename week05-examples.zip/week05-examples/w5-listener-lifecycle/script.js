
const button = document.querySelector("#test-click");
const output = document.querySelector("#listener-count");
const note = document.querySelector("#listener-note");
let count = 0;
let added = [];
function record() {
  count = count + 1;
  output.textContent = "실행 " + count + "회";
}
document.querySelector("#register-same").addEventListener("click", function () {
  button.addEventListener("click", record);
  button.addEventListener("click", record);
  note.textContent = "같은 record 함수를 두 번 전달했습니다.";
});
document.querySelector("#register-new").addEventListener("click", function () {
  for (let i = 0; i < 2; i = i + 1) {
    const handler = function () { record(); };
    button.addEventListener("click", handler);
    added.push(handler);
  }
  note.textContent = "새 함수 두 개를 추가했습니다.";
});
document.querySelector("#remove-handlers").addEventListener("click", function () {
  button.removeEventListener("click", record);
  added.forEach(function (handler) {
    button.removeEventListener("click", handler);
  });
  added = [];
  note.textContent = "연결을 해제했습니다. 횟수는 이전 기록입니다.";
});
