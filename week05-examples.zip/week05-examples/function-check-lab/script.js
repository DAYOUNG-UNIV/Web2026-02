function calculateTotal(price, count) {
  return price * count;
}
console.log(calculateTotal(3000, 1) === 3000);
console.log(calculateTotal(2500, 2) === 5000);
console.log(calculateTotal(3000, 5) === 15000);