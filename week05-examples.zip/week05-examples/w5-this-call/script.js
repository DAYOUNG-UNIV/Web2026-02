
"use strict";
const room = {
  title: "빛 전시",
  readTitle() {
    return this.title;
  }
};
console.log("메서드 호출:", room.readTitle());
const read = room.readTitle;
console.log("지정해서 호출:", read.call({ title: "숲 전시" }));
const boundRead = read.bind(room);
console.log("묶어 둔 함수:", boundRead());
