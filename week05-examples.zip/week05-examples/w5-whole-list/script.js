
const works = ["숲", "바다", "도시"];
const mount = document.querySelector("#mount");
const output = document.querySelector("#connected");

function buildList() {
  const list = document.createElement("ul");
  console.log("문서에 붙이기 전:", list.isConnected);
  works.forEach(function (work) {
    const item = document.createElement("li");
    item.textContent = work;
    list.appendChild(item);
  });
  mount.replaceChildren(list);
  output.textContent = "문서 연결: " + list.isConnected +
    " / 항목 수: " + list.children.length;
}
document.querySelector("#build-list").addEventListener("click", buildList);
