
const questions = [
  {
    text: "전시에 들어서면 먼저 무엇을 하나요?",
    options: [
      { text: "전체 동선을 둘러본다", type: "walk" },
      { text: "마음에 드는 작품 앞에 머문다", type: "look" }
    ]
  },
  {
    text: "작품 설명을 읽을 때는?",
    options: [
      { text: "전체 주제와 순서를 연결한다", type: "walk" },
      { text: "한 작품의 세부 이야기를 읽는다", type: "look" }
    ]
  },
  {
    text: "전시를 보고 남기고 싶은 것은?",
    options: [
      { text: "전체 공간과 이동의 기억", type: "walk" },
      { text: "인상 깊은 한 장면", type: "look" }
    ]
  }
];

const results = {
  walk: { title: "공간을 연결하는 감상", image: "🚶", description: "전체의 흐름과 작품 사이의 관계에 관심을 둔 선택이 많았습니다." },
  look: { title: "한 장면에 머무는 감상", image: "🔎", description: "한 작품의 세부 내용에 관심을 둔 선택이 많았습니다." }
};

let questionIndex = 0;
let scores = { walk: 0, look: 0 };
const startScreen = document.querySelector("#start-screen");
const questionScreen = document.querySelector("#question-screen");
const resultScreen = document.querySelector("#result-screen");
const title = document.querySelector("#question-title");
const answers = document.querySelector("#answers");

function startQuiz() {
  questionIndex = 0;
  scores = { walk: 0, look: 0 };
  startScreen.hidden = true;
  resultScreen.hidden = true;
  questionScreen.hidden = false;
  showQuestion();
}

function showQuestion() {
  const question = questions[questionIndex];
  title.textContent = question.text;
  document.querySelector("#quiz-progress").max = questions.length;
  document.querySelector("#quiz-progress").value = questionIndex;
  document.querySelector("#progress-text").textContent = (questionIndex + 1) + " / " + questions.length + "번째 질문";
  answers.replaceChildren();
  question.options.forEach(function (option) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = option.text;
    button.addEventListener("click", function () {
      selectAnswer(option.type);
    });
    answers.appendChild(button);
  });
  title.focus();
}

function selectAnswer(type) {
  scores[type] = scores[type] + 1;
  questionIndex = questionIndex + 1;
  if (questionIndex < questions.length) {
    showQuestion();
  } else {
    showResult();
  }
}

function showResult() {
  // 동점이면 walk를 선택하는 규칙입니다.
  let resultType = "walk";
  if (scores.look > scores.walk) resultType = "look";
  const result = results[resultType];
  questionScreen.hidden = true;
  resultScreen.hidden = false;
  document.querySelector("#quiz-progress").value = questions.length;
  document.querySelector("#result-title").textContent = result.title;
  document.querySelector("#result-description").textContent = result.description;
  document.querySelector("#result-image").textContent = result.image;
  document.querySelector("#result-image").setAttribute("aria-label", result.title + " 아이콘");
  document.querySelector("#result-score").textContent = "공간 " + scores.walk + "점 / 장면 " + scores.look + "점 · " + questions.length + "개 응답 완료";
  document.querySelector("#result-title").focus();
}

document.querySelector("#start-quiz").addEventListener("click", startQuiz);
document.querySelector("#restart-quiz").addEventListener("click", startQuiz);
