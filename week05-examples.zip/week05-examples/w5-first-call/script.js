function greet() {
  console.log("안녕하세요");
}

console.log("호출 전");
greet();
console.log("호출 후");