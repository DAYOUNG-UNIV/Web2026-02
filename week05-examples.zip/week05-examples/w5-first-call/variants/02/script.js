function greet() {
  console.log("안녕하세요");
}

greet();
greet();