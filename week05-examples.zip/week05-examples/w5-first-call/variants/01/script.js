function greet() {
  console.log("안녕하세요");
}

console.log("호출 전");
// greet(); 를 호출하지 않았습니다.
console.log("호출 후");