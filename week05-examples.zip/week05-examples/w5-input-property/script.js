
const input = document.querySelector("#visitor");
const report = document.querySelector("#value-report");

function showValues() {
  report.textContent =
    'HTML 속성 getAttribute("value"): ' + input.getAttribute("value") +
    "\n현재 값 input.value: " + input.value +
    "\n초기값 input.defaultValue: " + input.defaultValue;
}
function setValue() {
  input.value = "서준";
  showValues();
}
document.querySelector("#set-value").addEventListener("click", setValue);
input.addEventListener("input", showValues);
document.querySelector("#profile").addEventListener("reset", function () {
  // 기본 reset 동작이 끝난 다음 값을 읽습니다.
  setTimeout(showValues, 0);
});
showValues();
