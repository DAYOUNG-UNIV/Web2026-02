document.querySelector("#add").addEventListener("click", () => {
  const item = document.createElement("li");
  item.textContent = "추가 요청 사항 확인";
  document.querySelector("#list").appendChild(item);
});