function area(width, height) {
  return width * height;
}
const areaShort = (width, height) => width * height;
console.log(area(10, 5));
console.log(areaShort(10, 5));