
function calculateTotal(quantity) {
  if (!Number.isInteger(quantity) || quantity < 1) {
    return "수량을 확인하세요.";
  }
  console.log("가격 계산 실행");
  return 3000 * quantity;
}
console.log(calculateTotal(2));
console.log(calculateTotal(0));
console.log(calculateTotal());

function showOnly(value) {
  console.log(value);
}
const result = showOnly(6000);
console.log("반환값:", result);
