
const source = document.querySelector("#json-text");
const result = document.querySelector("#json-result");
const state = document.querySelector("#json-state");
function readJSON() {
  try {
    const data = JSON.parse(source.value);
    result.textContent = JSON.stringify(data, null, 2);
    state.textContent = "해석 성공 · typeof: " + typeof data;
  } catch (error) {
    result.textContent = "값을 만들지 못했습니다.";
    state.textContent = error.name + " · 따옴표와 쉼표를 확인하세요.";
  }
}
document.querySelector("#json-read").addEventListener("click", readJSON);
document.querySelector("#json-invalid").addEventListener("click", function () {
  source.value = '{title:"숲",count:3}';
  readJSON();
});
document.querySelector("#json-reset").addEventListener("click", function () {
  source.value = '{"title":"숲","count":3}';
  result.textContent = "아직 읽지 않았습니다.";
  state.textContent = "버튼으로 문자열을 해석합니다.";
});
