
const list = document.querySelector("#order-list");
const button = document.querySelector("#order-start");
function write(message) {
  const item = document.createElement("li");
  item.textContent = message;
  list.append(item);
}
button.addEventListener("click", function () {
  list.replaceChildren();
  button.disabled = true;
  write("1. 현재 코드 시작");
  setTimeout(function () {
    write("2. 타이머 콜백");
    button.disabled = false;
  }, 0);
  Promise.resolve().then(function () {
    write("3. Promise 콜백");
  });
  write("4. 현재 코드 끝");
});
