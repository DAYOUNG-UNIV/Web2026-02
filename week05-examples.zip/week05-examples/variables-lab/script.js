const price = 3000;
let quantity = 1;
quantity = 2;
console.log(price * quantity);