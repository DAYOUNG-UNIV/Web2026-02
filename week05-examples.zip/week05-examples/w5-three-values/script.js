console.log(typeof 2);
console.log(typeof "2");
console.log(typeof true);