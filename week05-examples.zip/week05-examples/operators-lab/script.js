let quantity = 2;
quantity += 1;
console.log(3000 * quantity);
console.log(7 % 3);
console.log(quantity === 3);
console.log(quantity >= 1 && quantity <= 5);