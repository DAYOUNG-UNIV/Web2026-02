
let score = 80;
score += 5;
console.log(score);
score -= 10;
console.log(score);
console.log(10 / 4, 10 % 4);
console.log(85 >= 80, 85 < 90);
console.log(2 === "2", 2 == "2");
console.log(2 !== "2", 2 != "2");
