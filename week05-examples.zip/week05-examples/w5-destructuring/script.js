
const artwork = { title: "숲", size: { width: 400 } };
const { title, author = "미기재" } = artwork;
console.log(title, author);
const colors = ["초록", "파랑"];
const [first, second] = colors;
console.log(first, second);
const extended = [...colors, "보라"];
console.log(colors, extended);
const copy = { ...artwork, title: "새 전시" };
console.log(artwork.title, copy.title);
copy.size.width = 800;
console.log("중첩 객체 공유:", artwork.size.width, copy.size.width);
