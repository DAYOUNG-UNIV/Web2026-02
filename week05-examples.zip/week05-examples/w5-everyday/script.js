
let zoom = 1;
let liked = false;
const map = document.querySelector("#map");
const zoomValue = document.querySelector("#zoom-value");

function showZoom() {
  map.style.transform = "scale(" + zoom + ")";
  zoomValue.textContent = Math.round(zoom * 100) + "%";
}
function zoomIn() {
  zoom = Math.min(2, zoom + 0.25);
  showZoom();
}
function zoomOut() {
  zoom = Math.max(1, zoom - 0.25);
  showZoom();
}
document.querySelector("#zoom-in").addEventListener("click", zoomIn);
document.querySelector("#zoom-out").addEventListener("click", zoomOut);

const likeButton = document.querySelector("#like");
function toggleLike() {
  liked = !liked;
  likeButton.setAttribute("aria-pressed", String(liked));
  likeButton.textContent = liked ? "♥ 좋아요 취소" : "♡ 좋아요";
  document.querySelector("#like-count").textContent = liked ? "13" : "12";
}
likeButton.addEventListener("click", toggleLike);

const category = document.querySelector("#category");
function filterWorks() {
  let count = 0;
  document.querySelectorAll("[data-category]").forEach(function (item) {
    const match = category.value === "all" || item.dataset.category === category.value;
    item.hidden = !match;
    if (match) count = count + 1;
  });
  document.querySelector("#filter-count").textContent = count + "개 작품";
}
category.addEventListener("change", filterWorks);
