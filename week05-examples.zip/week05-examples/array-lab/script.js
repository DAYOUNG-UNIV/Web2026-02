const menus = ["차", "커피"];
console.log(menus[0]);
console.log(menus.length);
menus.push("주스");
console.log(menus[2]);
console.log(menus.length);