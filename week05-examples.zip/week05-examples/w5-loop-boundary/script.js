
const items = ["숲", "바다", "도시"];
for (let i = 0; i < items.length; i = i + 1) {
  console.log(i, items[i]);
}
