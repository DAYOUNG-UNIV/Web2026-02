const walkButton = document.querySelector("#walk");
const restButton = document.querySelector("#rest");
const result = document.querySelector("#result");

function chooseWalk() {
  result.textContent = "산책을 선택했습니다.";
}

function chooseRest() {
  result.textContent = "휴식을 선택했습니다.";
}

walkButton.addEventListener("click", chooseWalk);
restButton.addEventListener("click", chooseRest);