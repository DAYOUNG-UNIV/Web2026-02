console.log(Boolean(""));
console.log(Boolean(0));
console.log(Boolean(null));
console.log(Boolean([]));
console.log(Boolean({}));
console.log(Boolean("false"));