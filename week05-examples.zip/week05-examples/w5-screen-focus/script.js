
const first = document.querySelector("#choice-screen");
const result = document.querySelector("#choice-result");
const choice = document.querySelector("#view-choice");
const showButton = document.querySelector("#show-choice");
const heading = document.querySelector("#choice-title");
const focusOption = document.querySelector("#move-focus");
choice.addEventListener("change", function () {
  showButton.disabled = choice.value === "";
});
showButton.addEventListener("click", function () {
  document.querySelector("#choice-description").textContent = choice.value;
  first.hidden = true;
  result.hidden = false;
  if (focusOption.checked) {
    heading.focus();
  }
  reportFocus();
});
document.querySelector("#choose-again").addEventListener("click", function () {
  result.hidden = true;
  first.hidden = false;
  choice.value = "";
  showButton.disabled = true;
  choice.focus();
});
function reportFocus() {
  const active = document.activeElement;
  document.querySelector("#focus-state").textContent =
    "현재 초점: " + (active.id || active.tagName);
}
document.addEventListener("focusin", reportFocus);
reportFocus();
