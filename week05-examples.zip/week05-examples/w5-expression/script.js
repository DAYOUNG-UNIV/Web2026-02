
const withoutGroup = 3000 + 500 * 2;
const withGroup = (3000 + 500) * 2;
console.log(withoutGroup);
console.log(withGroup);
// 주석은 계산에 포함되지 않습니다.
console.log(2 + 3 * 4);
console.log((2 + 3) * 4);
