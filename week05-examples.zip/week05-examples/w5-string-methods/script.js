
const raw = "  Web 전시  ";
const clean = raw.trim();
console.log("원문:", raw);
console.log("정리:", clean);
console.log("길이:", clean.length);
console.log("Web 포함:", clean.includes("Web"));
console.log("web 포함:", clean.includes("web"));
console.log("소문자:", clean.toLowerCase());
