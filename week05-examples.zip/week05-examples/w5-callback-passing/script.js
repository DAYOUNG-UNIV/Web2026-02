
const button = document.querySelector("#act");
const output = document.querySelector("#calls");
let count = 0;
function handleClick() {
  count = count + 1;
  output.textContent = count + "회";
}
button.addEventListener("click", handleClick);
