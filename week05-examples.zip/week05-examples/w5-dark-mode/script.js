
const button = document.querySelector("#theme");
const status = document.querySelector("#theme-status");

function toggleTheme() {
  const isDark = document.body.classList.toggle("dark");
  button.setAttribute("aria-pressed", String(isDark));
  if (isDark) {
    button.textContent = "다크 모드 끄기";
    status.textContent = "어두운 모드";
  } else {
    button.textContent = "다크 모드 켜기";
    status.textContent = "밝은 모드";
  }
}
button.addEventListener("click", toggleTheme);
