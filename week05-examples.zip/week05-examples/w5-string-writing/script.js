
console.log("I'm a student.");
console.log('I\'m a student.');

const name = "민지";
const classRoom = 302;
console.log(name + "님, " + classRoom + "호 강의실입니다.");
console.log(`${name}님, ${classRoom}호 강의실입니다.`);
console.log("첫째 줄\n둘째 줄");
