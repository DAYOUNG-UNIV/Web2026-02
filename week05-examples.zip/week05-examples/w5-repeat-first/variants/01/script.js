for (let count = 1; count <= 0; count = count + 1) {
  console.log(count);
}