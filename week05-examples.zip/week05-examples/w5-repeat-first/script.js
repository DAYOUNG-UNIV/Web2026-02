for (let count = 1; count <= 3; count = count + 1) {
  console.log(count);
}