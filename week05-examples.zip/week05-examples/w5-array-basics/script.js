
const fruits = ["사과", "바나나", "딸기"];
console.log(fruits[0]);
console.log(fruits[1]);
console.log(fruits[2]);
console.log(fruits[3]);
console.log(fruits.length);
fruits.push("오렌지");
console.log(fruits);

const mixed = [1, 2, "Three", true, null];
console.log(mixed[2]);
