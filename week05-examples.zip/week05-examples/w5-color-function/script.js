
const title = document.querySelector("#color-title");
const output = document.querySelector("#color-value");

function changeColor(color) {
  title.style.color = color;
  output.textContent = "선택한 색상: " + color;
}

function chooseRed() { changeColor("red"); }
function chooseGreen() { changeColor("green"); }
function chooseBlue() { changeColor("blue"); }

document.querySelector("#red").addEventListener("click", chooseRed);
document.querySelector("#green").addEventListener("click", chooseGreen);
document.querySelector("#blue").addEventListener("click", chooseBlue);
