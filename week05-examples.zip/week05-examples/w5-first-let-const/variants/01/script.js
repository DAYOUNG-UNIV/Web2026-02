const price = 3000;
console.log(price);