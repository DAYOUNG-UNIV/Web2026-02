const price = 3000;
price = 4000;
console.log(price);