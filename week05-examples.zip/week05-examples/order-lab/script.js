const form = document.querySelector("#order");
const drink = document.querySelector("#drink");
const quantity = document.querySelector("#quantity");
const total = document.querySelector("#total");

function calculateTotal(price, count) {
  return price * count;
}
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const count = quantity.valueAsNumber;
  if (!Number.isInteger(count) || count < 1 || count > 5) {
    total.textContent = "수량을 1~5 사이의 정수로 입력하세요.";
    return;
  }
  const price = drink.value === "tea" ? 2500 : 3000;
  const amount = calculateTotal(price, count);
  total.textContent = "합계: " + amount.toLocaleString("ko-KR") + "원 (시연)";
});