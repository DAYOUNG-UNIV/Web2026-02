
const root = document.documentElement;

function changeTheme() {
  root.style.setProperty("--accent", "#6741a5");
}

function resetTheme() {
  root.style.removeProperty("--accent");
}

document.querySelector("#theme-change").addEventListener("click", changeTheme);
document.querySelector("#theme-reset").addEventListener("click", resetTheme);
