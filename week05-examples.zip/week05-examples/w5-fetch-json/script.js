
const button = document.querySelector("#fetch-start");
const status = document.querySelector("#fetch-state");
const list = document.querySelector("#fetch-list");
async function readWorks() {
  const mode = document.querySelector("#fetch-data").value;
  let text = '["숲", "바다"]';
  if (mode === "invalid") text = '["숲",]';
  if (mode === "wrong") text = 'null';
  const file = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(file);
  button.disabled = true;
  list.replaceChildren();
  status.textContent = "읽는 중";
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("응답 상태: " + response.status);
    const works = await response.json();
    if (!Array.isArray(works)) throw new Error("목록은 배열이어야 합니다.");
    for (const title of works) {
      if (typeof title !== "string") throw new Error("제목은 문자열이어야 합니다.");
    }
    for (const title of works) {
      const item = document.createElement("li");
      item.textContent = title;
      list.append(item);
    }
    status.textContent = "완료 · " + works.length + "개";
  } catch (error) {
    status.textContent = "실패 · " + error.message;
  } finally {
    button.disabled = false;
    URL.revokeObjectURL(url);
  }
}
button.addEventListener("click", readWorks);
