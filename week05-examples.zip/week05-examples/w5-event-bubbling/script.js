
const log = document.querySelector("#path-log");
let history = "";
function record(event) {
  history += "target: " + event.target.id +
    " / currentTarget: " + event.currentTarget.id + "\n";
  log.textContent = history;
}
document.querySelector("#open").addEventListener("click", function (event) {
  record(event);
  if (document.querySelector("#stop").checked) {
    event.stopPropagation();
    log.textContent += "부모로의 전달을 중단했습니다.\n";
  }
});
document.querySelector("#panel").addEventListener("click", record);
document.querySelector("#clear").addEventListener("click", function () {
  history = "";
  log.textContent = "기록 없음";
});
