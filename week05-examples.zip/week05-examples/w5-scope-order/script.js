
const title = "전체 전시";
{
  const title = "특별 전시";
  console.log("블록 안:", title);
}
console.log("블록 밖:", title);

try {
  console.log(later);
  let later = 3;
} catch (error) {
  console.log("초기화 전:", error.name);
}
