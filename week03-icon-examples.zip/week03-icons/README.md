# Font Awesome 아이콘 예제

index.html을 브라우저에서 엽니다. 아이콘 종류, style.css의 크기와 색을 수정합니다. 버튼의 실제 동작은 구현하지 않은 CSS 예제입니다.

CSS 폴더와 webfonts 폴더의 상대 위치를 유지합니다. 같은 폴더 구조로 웹에 배포할 수 있습니다. Font Awesome Free 7.3.1, Classic Solid. 라이선스는 assets/fontawesome/LICENSE.txt에 포함되어 있습니다.
