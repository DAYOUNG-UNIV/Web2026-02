# Font Awesome Free 7.3.1

Classic Solid: official CSS and WOFF2 from https://github.com/FortAwesome/Font-Awesome/tree/7.3.1
Fonts: SIL OFL 1.1; code: MIT; icons: CC BY 4.0. See LICENSE.txt.

The course embeds an unchanged font as a data URL only inside the interactive preview. Download examples retain the original CSS/webfonts directory structure.
