# Tailwind 전시 카드

index.html을 열면 미리 생성한 style.css로 카드가 표시됩니다.

## 새로운 클래스를 추가할 때

1. Node.js의 LTS 버전을 설치합니다. Node.js는 CSS 생성 도구를 실행하는 환경이며 npm도 함께 설치됩니다.
2. 이 폴더를 VS Code로 열고 터미널에서 `npm install`을 실행합니다.
3. `npm run dev`를 실행한 채 index.html의 클래스를 수정하고 저장합니다.
4. 브라우저를 새로고침합니다. 종료는 터미널에서 Ctrl+C를 누릅니다.

파일 변경을 계속 감시하지 않고 한 번만 만들려면 `npm run build`를 사용합니다.
style.css는 생성 결과이므로 직접 고치지 않습니다. 공통 스타일은 input.css에 작성합니다.
새 클래스를 추가했는데 달라지지 않으면 CSS 생성 여부와 link 경로를 확인합니다.

## 배포

index.html과 생성한 style.css, 사용하는 이미지와 LICENSE를 함께 올립니다.
node_modules는 게시하지 않습니다. 방문자의 브라우저에는 Node.js나 Tailwind 실행 도구가 필요하지 않습니다.

이 예제는 Tailwind CSS 4.3.3을 사용합니다. 카드의 관심 작품 버튼에는 클릭 동작이 없습니다.
https://tailwindcss.com/docs/installation/tailwind-cli
