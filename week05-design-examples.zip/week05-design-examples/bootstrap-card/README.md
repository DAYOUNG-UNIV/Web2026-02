# Bootstrap 전시 카드

index.html을 열면 Bootstrap 5.3.8 CSS가 적용됩니다. 별도의 설치나 CSS 생성 과정은 없습니다.
카드 여백은 p-3 → p-4, 버튼은 btn-primary → btn-outline-primary로 바꾸어 비교합니다.
col-12는 한 줄 전체, col-md-6은 화면 너비 768px 이상에서 한 줄의 절반을 사용합니다.
관심 작품 버튼의 스타일만 구현했으며 목록을 변경하는 기능은 없습니다.

직접 만든 CSS를 추가하려면 Bootstrap CSS 뒤에 별도 파일로 연결합니다. style.css의 배포 코드를 직접 수정하지 않습니다.
https://getbootstrap.com/docs/5.3/components/card/
