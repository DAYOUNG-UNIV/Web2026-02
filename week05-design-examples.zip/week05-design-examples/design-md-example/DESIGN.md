---
name: 작은 전시
colors:
  primary: "#0f766e"
  on-primary: "#ffffff"
spacing:
  card: 24px
---
## Overview
사진과 캡션을 차례로 읽는 전시 페이지입니다.

## Colors
primary는 주요 동작 버튼에 사용합니다.
버튼 글자는 on-primary를 사용합니다.

## Layout
카드 안쪽 여백은 spacing.card에 맞춥니다.
좁은 화면은 한 열, 넓은 화면은 두 열로 배치합니다.

## Do's and Don'ts
버튼에는 수행할 동작을 적습니다.
키보드 초점은 눈에 보이게 표시합니다.
