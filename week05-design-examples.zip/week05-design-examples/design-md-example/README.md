# DESIGN.md와 CSS 비교

index.html을 열면 두 카드가 표시됩니다. 버튼의 페이지 이동은 구현하지 않은 서식 예제입니다.

1. DESIGN.md의 primary 색이나 card 여백을 바꿉니다.
2. 문서를 저장해도 화면의 CSS는 바뀌지 않는 것을 확인합니다.
3. style.css 맨 앞의 --color-action, --space-card를 같은 값으로 수정하고 새로고침합니다.

DESIGN.md는 Google Labs 형식의 일부 항목만 사용한 입문 예제입니다.
전체 디자인 시스템이나 모든 구성 요소의 상태를 정의한 문서는 아닙니다.
공식 안내: https://stitch.withgoogle.com/docs/design-md/overview
형식 명세: https://github.com/google-labs-code/design.md/blob/main/docs/spec.md
