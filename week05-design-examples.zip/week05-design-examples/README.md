# 버튼과 전시 카드 스타일 비교

각 폴더의 index.html을 열어 봅니다. 버튼의 동작은 구현하지 않은 서식 예제입니다.

전시 카드 예제:
- bootstrap-card: Bootstrap 카드·격자·유틸리티 예제
- tailwind-card: Tailwind 카드와 CSS 생성 프로젝트. 새 클래스를 추가할 때는 해당 폴더의 README.md를 참고합니다.

- direct: 직접 작성한 CSS
- bootstrap: Bootstrap 5.3.8 배포 CSS
- tailwind: Tailwind CSS 4.3.3으로 미리 생성한 CSS

Tailwind 예제에 없는 새 클래스를 쓰려면 CSS를 다시 생성해야 합니다. 생성한 style.css를 직접 편집하지 않습니다.
3주차 교안의 Tailwind CSS 생성 방법: https://dayoung-univ.github.io/Web2026-02/week3#tailwind-build

DESIGN.md는 디자인 기준을 적는 수업용 메모입니다. Google Labs 형식의 스키마 검증용 예제가 아닙니다. 문서만 바꿔서는 CSS가 바뀌지 않습니다.

추가 예제: design-md-example 폴더에는 구조화한 DESIGN.md와 같은 기준을 반영한 HTML·CSS가 있습니다. 해당 폴더의 README.md를 따라 값을 바꿔 봅니다.
