import { works } from "./data.js";

const list = document.querySelector("#works");
for (const title of works) {
  const item = document.createElement("li");
  item.textContent = title;
  list.append(item);
}
