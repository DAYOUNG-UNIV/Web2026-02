export const works = ["숲", "바다"];
